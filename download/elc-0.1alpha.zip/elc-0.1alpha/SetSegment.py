"""
    TEMOA (Tools for Energy Model Optimization and Analysis) 
    Copyright (C) 2010 TEMOA Developer Team 

    This file is part of TEMOA.
    TEMOA is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    any later version.

    TEMOA is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with TEMOA.  If not, see <http://www.gnu.org/licenses/>.
"""


def SegmentSet_Init ( model ):
	ans = [
	  '%s %02d:00' % (i, hour)
	  for i in ( 'Spring', 'Summer', 'Fall', 'Winter' )
	  for hour in range(0, 24, 4)
	  #for half in range(0, 60, 30)
	]

	ans = ['Year Round']

	return ans

